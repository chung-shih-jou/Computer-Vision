from util import *
import cv2
import numpy as np
from stereo import *
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
# You have to degrade cv2 version to
# pip install opencv-python==3.4.2.16
# pip install opencv-contrib-python==3.4.2.16

def unCropWrapPerspective(
        src, H,
        flags = cv2.INTER_LINEAR,
        borderMode = cv2.BORDER_CONSTANT,
        borderValue = 0):

    [h, w] = src.shape[:2]
    lin_homg_pts = np.array([
        [0, w, w, 0],
        [0, 0, h, h],
        [1, 1, 1, 1]])
    transf_lin_homg_pts = H.dot(lin_homg_pts)
    transf_lin_homg_pts /= transf_lin_homg_pts[2, :]
    min_x = np.floor(np.min(transf_lin_homg_pts[0])).astype(int)
    min_y = np.floor(np.min(transf_lin_homg_pts[1])).astype(int)
    max_x = np.ceil(np.max(transf_lin_homg_pts[0])).astype(int)
    max_y = np.ceil(np.max(transf_lin_homg_pts[1])).astype(int)

    anchor_x, anchor_y = 0, 0
    transl_transf = np.eye(3, 3)
    if min_x < 0:
        anchor_x = -min_x
        transl_transf[0, 2] += anchor_x
    if min_y < 0:
        anchor_y = -min_y
        transl_transf[1, 2] += anchor_y
    shifted_transf = transl_transf.dot(H)
    shifted_transf /= shifted_transf[2, 2]
    
    transf_lin_homg_pts = shifted_transf.dot(lin_homg_pts)
    transf_lin_homg_pts /= transf_lin_homg_pts[2, :]

    pad_widths = [anchor_y, max(max_y, h) - h,
                  anchor_x, max(max_x, w) - w]
    dst_padded = cv2.copyMakeBorder(src, *pad_widths,
                                    borderType = borderMode, value = borderValue)
    dst_pad_h, dst_pad_w = dst_padded.shape[:2]
    src_warped = cv2.warpPerspective(
        src, shifted_transf, (dst_pad_w, dst_pad_h),
        flags = flags, borderMode = borderMode, borderValue = borderValue)

    return src_warped, shifted_transf

def transPoint(pts, H):
	'''
	Parameters
	----------
	pts : array_like 
		[N x 2]
	H : array_like
		[3 x 3]
	'''
	N = pts.shape[0]
	pts = np.concatenate((pts, np.ones((N,1))), axis = 1)
	dst = H.dot(pts.T).T
	dst /= dst[:,2].reshape(-1,1)
	return dst[:,:2]

def drawlines(img, lines, pts):
    [r,c,ch] = img.shape
    imgg = img.copy()
    for r,pt in zip(lines,pts):
        color = tuple(np.random.randint(0,255,3).tolist())
        x0,y0 = map(int, [0, -r[2]/r[1] ])
        x1,y1 = map(int, [c, -(r[2]+r[0]*c)/r[1] ])
        imgg = cv2.line(imgg, (x0,y0), (x1,y1), color, 1)
        imgg = cv2.circle(imgg, tuple(pt[0]), 5, color, -1)
    return imgg

def siftFeatureMatching(img_l, img_r, n_tree = 5, n_checks = 20, n_thre = 0.55):
    sift = cv2.xfeatures2d.SIFT_create()
    kp_l, des_l = sift.detectAndCompute(img_l, None)
    kp_r, des_r = sift.detectAndCompute(img_r, None)
    
    # matching
    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = n_tree)
    search_params = dict(checks = n_checks)
    flann = cv2.FlannBasedMatcher(index_params,search_params)
    matches = flann.knnMatch(des_r, des_l, k=2)
    goodmatches, pts_l, pts_r = [], [], []

    for i, (m, n) in enumerate(matches):
        if m.distance < n_thre * n.distance:
            pts_l.append(list(kp_l[m.trainIdx].pt))
            pts_r.append(list(kp_r[m.queryIdx].pt))
            goodmatches.append([m,n])
    pts_l = np.float32(np.asarray(pts_l)).reshape(-1,1,2)
    pts_r = np.float32(np.asarray(pts_r)).reshape(-1,1,2)
    goodmatches = np.asarray(goodmatches)
    return kp_l, kp_r, pts_l, pts_r, goodmatches
    
def reverse(src, H, dims):
    invH = np.linalg.inv(H)
    return cv2.warpPerspective(src, invH, dims)

def rectify(img_l, img_r):
    if len(img_l.shape) == 2:
        img_l = cv2.cvtColor(img_l, cv2.COLOR_GRAY2RGB)
        img_r = cv2.cvtColor(img_r, cv2.COLOR_GRAY2RGB)
    [h, w, ch] = img_l.shape
    kp_l, kp_r, pts_l, pts_r, matches = siftFeatureMatching(img_l, img_r)

    # RANSAC : find fundamental matrix
    f_mat, mask = cv2.findFundamentalMat(pts_l, pts_r, cv2.RANSAC, 0.2, 0.95)
    matches = matches[mask.ravel() == 1]
    pts_l = pts_l[mask.ravel() == 1]
    pts_r = pts_r[mask.ravel() == 1]
    img = cv2.drawMatchesKnn(img_l, kp_l, img_r, kp_r, matches[:10], None)
    # cv2.imwrite('matchingresult.png', img)

    # Compute H1, H2
    _, H1, H2 = cv2.stereoRectifyUncalibrated(pts_l, pts_r, f_mat, (w, h))
    line_l = cv2.computeCorrespondEpilines(pts_r.reshape(-1,1,2), 2,f_mat)
    line_l = line_l.reshape(-1,3) # ax + by + c = 0
    line_r = cv2.computeCorrespondEpilines(pts_l.reshape(-1,1,2), 1,f_mat)
    line_r = line_r.reshape(-1,3)
    img1 = drawlines(img_l, line_l, pts_l)
    img2 = drawlines(img_r, line_r, pts_r)
    vis = np.concatenate((img1, img2), axis=1)
    cv2.imwrite('unrectified.png', vis)

    # test
    # img1 = cv2.warpPerspective(img1, H1, (w,h), flags=cv2.INTER_LINEAR)
    # img2 = cv2.warpPerspective(img2, H2, (w,h), flags=cv2.INTER_LINEAR)
    # vis = np.concatenate((img1, img2), axis=1)
    # cv2.imwrite('rectified1.png', vis)

    # Transform Line & Points
    # img1 = cv2.warpPerspective(img_l, H1, (w,h), flags=cv2.INTER_LINEAR)
    # img2 = cv2.warpPerspective(img_r, H2, (w,h), flags=cv2.INTER_LINEAR)
    # line_l_ = np.linalg.inv(H1).T.dot(line_l.T).T
    # pts_l_ = np.float32(transPoint(pts_l.reshape(-1,2), H1).reshape(-1,1,2))
    # line_r_ = np.linalg.inv(H2).T.dot(line_r.T).T
    # pts_r_ = np.float32(transPoint(pts_r.reshape(-1,2), H2).reshape(-1,1,2))
    # img1 = drawlines(img1, line_l_, pts_l_)
    # img2 = drawlines(img2, line_r_, pts_r_)
    # vis = np.concatenate((img1, img2), axis=1)
    # cv2.imwrite('rectified2.png', vis)

    # padded version
    img1, H1t = unCropWrapPerspective(img_l, H1)
    img2, H2t = unCropWrapPerspective(img_r, H2)
    line_l_ = np.linalg.inv(H1t).T.dot(line_l.T).T
    pts_l_ = np.float32(transPoint(pts_l.reshape(-1,2), H1t).reshape(-1,1,2))
    line_r_ = np.linalg.inv(H2t).T.dot(line_r.T).T
    pts_r_ = np.float32(transPoint(pts_r.reshape(-1,2), H2t).reshape(-1,1,2))
    # draw epipolar lines
    # img1 = drawlines(img1, line_l_, pts_l_)
    # img2 = drawlines(img2, line_r_, pts_r_)

    h1, w1 = img1.shape[:2]
    h2, w2 = img2.shape[:2]
    leftup1 = [np.min(pts_l_[:,0,0]), np.min(pts_l_[:,0,1])]
    leftup2 = [np.min(pts_r_[:,0,0]), np.min(pts_r_[:,0,1])]
    if (leftup1[1] > leftup2[1]):
        up = int(np.ceil(np.mean((pts_l_-pts_r_).reshape(-1,2)[:,1])))
        padding = (h1 - h2) - up
        if (padding < 0):
            pad_widths = [up, 0, 0, 0]
            img2 = cv2.copyMakeBorder(img2, *pad_widths, borderType = cv2.BORDER_CONSTANT, value = 0)
            pad_widths = [0, -padding, 0, 0]
            img1 = cv2.copyMakeBorder(img1, *pad_widths, borderType = cv2.BORDER_CONSTANT, value = 0)
        else:
            pad_widths = [up, padding, 0 , 0]
            img2 = cv2.copyMakeBorder(img2, *pad_widths, borderType = cv2.BORDER_CONSTANT, value = 0)
    elif (leftup2[1] > leftup1[1]):
        up = int(np.ceil(np.mean((pts_r_-pts_l_).reshape(-1,2)[:,1])))
        padding = (h2 - h1) - up
        if (padding < 0):
            pad_widths = [up, 0, 0, 0]
            img1 = cv2.copyMakeBorder(img1, *pad_widths, borderType = cv2.BORDER_CONSTANT, value = 0)
            pad_widths = [0, -padding, 0, 0]
            img2 = cv2.copyMakeBorder(img2, *pad_widths, borderType = cv2.BORDER_CONSTANT, value = 0)
        else:
            pad_widths = [up, padding, 0 , 0]
            img1 = cv2.copyMakeBorder(img1, *pad_widths, borderType = cv2.BORDER_CONSTANT, value = 0)

    img1 = cv2.resize(img1, (max(w1,w2), img1.shape[0]))
    img2 = cv2.resize(img2, (max(w1,w2), img1.shape[0]))
    vis = np.concatenate((img1, img2), axis=1)
    cv2.imwrite('rectified.png', vis)
    return img1, img2, H1t, H2t
