import numpy as np

def misMatchCheck(dr, i, j, max_disp):
    flag = False
    for d in range(max_disp+1):
        if d == dr[i, j - d]:
            flag = True
            break
    return flag
def cumFilter(src, horizontal = True):
    '''
    src : cost map [h, w]
    '''
    [h, w] = src.shape[:2]
    dst = np.zeros((h, w))
    if horizontal:
        for i in range(w):
            if i == 0:
                dst[:, i] = src[:, i]
            else:
                dst[:, i] = src[:, i] + dst[:, i - 1]
    else:
        for i in range(h):
            if i == 0:
                dst[i, :] = src[i, :]
            else:
                dst[i, :] = src[i, :] + dst[i - 1, :]
    return dst


def boxFilter(src, r): # src[h, w]
    if len(src.shape) > 2:
        h, w, ch = src.shape
        dst = np.zeros((h, w, ch))
        for i in range(ch):
            temp = pad(src[:,:,i], r)
            temp1 = np.cumsum(temp, axis = 0)
            temp1 = np.cumsum(temp1, axis = 1)
            temp2 = np.zeros((h+2*r+1, w+2*r+1))
            temp2[1:, 1:] = temp1
            dst[:, :, i] = temp2[2*r+1:, 2*r+1:] + temp2[0:h,0:w] - temp2[0:h, 2*r+1:] - temp2[2*r+1:, 0:w]
    else:
        h, w = src.shape
        src = pad(src, r)
        temp1 = np.cumsum(src, axis = 0)
        temp1 = np.cumsum(temp1, axis = 1)
        temp2 = np.zeros((h+2*r+1, w+2*r+1))
        temp2[1:, 1:] = temp1
        dst = temp2[2*r+1:, 2*r+1:] + temp2[0:h,0:w] - temp2[0:h, 2*r+1:] - temp2[2*r+1:, 0:w]
    return dst / ((2*r*1)**2) 

def pad(src, r): 
    '''
    src: [h, w, ch]
    pad_img: [h+2*r, w+2*r, ch]
    '''
    if len(src.shape) > 2:
        [x, y, z] = src.shape
        pad_img = np.zeros((x+2*r, y+2*r, z))
        for i in range(z):
            pad_img[:,:,i] = np.pad(src[:,:,i], (r,r), 'edge')
    else:
        pad_img = np.pad(src, (r,r), 'wrap')
    return pad_img

def hammingDist(src1, src2):
    h, w, ch = src1.shape
    dst = np.zeros((h, w))
    return np.sum(abs(src1 - src2), axis = 2)/ch

def eucliDist(r):
    x = np.arange(-r, r+1)
    y = np.arange(-r, r+1)
    xx, yy = np.meshgrid(x, y)
    temp = (xx*xx+ yy*yy)**0.5
    temp = temp/np.max(temp)
    return temp
