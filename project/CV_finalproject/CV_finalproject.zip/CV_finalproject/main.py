from util import *
import cv2
import numpy as np
from stereo import *
import imrectify
import imdisparity
# You have to degrade cv2 version to
# pip install opencv-python==3.4.2.16
# pip install opencv-contrib-python==3.4.2.16

# def main():
#     img = np.float32(cv2.imread('test.png'))
#     print(img.shape)
#     writePFM('test.pfm', img, scale=1)
#     print(cal_avgerr(readPFM('./data/Synthetic/TLD0.pfm'), readPFM('test.pfm')))


def main():
    # img_left = cv2.imread('im2.png')
    # img_right = cv2.imread('im6.png')
    # img_left = cv2.imread('./data/Real/TL2.bmp')
    # img_right = cv2.imread('./data/Real/TR2.bmp')

    img_left = cv2.imread('./data/Synthetic/TL0.png')
    img_right = cv2.imread('./data/Synthetic/TR0.png')
    
    h, w = img_left.shape[:2]
    recimg_left, recimg_right, H1t, H2t = imrectify.rectify(img_left, img_right)
    # cv2.imwrite('test1.png', recimg_left)
    max_disp = 60
    scale_factor = 4
    recdisp = imdisparity.disparity(recimg_left, recimg_right, max_disp)
    cv2.imwrite('test1.png', np.uint8(recdisp*scale_factor))
    output = imrectify.reverse(recdisp, H1t, (w, h))
    cv2.imwrite('test2.png', output)
    # cv2.imwrite('test2.png', np.uint8(output*scale_factor))


if __name__ == '__main__':
    main()