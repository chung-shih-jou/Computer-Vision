import numpy as np
import cv2
import time
from tools import *

HYPER = {}

# HYPER[1] = {'AGG_R':20, 'TRUNC':0.3, 'CENSUS_R':9, 'BFWMF_R':3, 'S1':0.5, 'S2':3.0, 'EPS':1e-4}
HYPER[1] = {'AGG_R':15, 'TRUNC':0.6, 'CENSUS_R':3, 'BFWMF_R':2, 'S1':0.5, 'S2':3.0, 'EPS':1e-4}
# HYPER[3] = {'AGG_R':10, 'TRUNC':0.4, 'CENSUS_R':3, 'BFWMF_R':3, 'S1':0.5, 'S2':3.0, 'EPS':1e-4}
# HYPER[4] = {'AGG_R':10, 'TRUNC':0.4, 'CENSUS_R':3, 'BFWMF_R':5, 'S1':0.5, 'S2':3.0, 'EPS':1e-4}
K = 0


def queryRegion(x, y, lab, region, cmap):
    # print(np.max(lab), np.min(lab))
    # print()
    up, down = region[x, y][:2]
    dst = []
    for i in range(up, down+1):
        left, right = region[i, y][2:]
        # print(left, right)
        for j in range(left, right+1):
            if cmap[i, j] == 1:

                dst.append(lab[i, j])
                # print(i, j, lab[i, j])
    return np.array(dst, dtype = np.int16)

def regionFilling(lab, cmap, region, area, thre1 = 0.7, thre2 = 0.7):
    h, w = lab.shape[:2]
    # for i in range(h):
    #     for j in range(w):
    #         print(lab[i, j])
    # print(type(lab))
    # print(lab)
    for i in range(h):
        for j in range(w):
            if cmap[i, j] == 0:
                # print()
                neighbor = queryRegion(i, j, lab, region, cmap)
                # print(neighbor)
                counts = neighbor.shape[0]
                hist = np.bincount(neighbor)
                if counts > thre1 * area[i, j] and np.max(hist) > thre2 * counts:
                    cmap[i, j] = 1
                    lab[i, j] = np.argmax(hist)
    return lab, cmap


def holeFilling(lab, cmap):
    h, w = lab.shape[:2]
    lab[cmap == 0] = -1
    f1 = np.zeros(lab.shape)
    insert = np.ones((h))
    for i in range(w): # left
        temp = lab[:, i]
        temp[temp == -1] = insert[temp == -1]
        insert[temp != -1] = temp[temp != -1]
        f1[:, i] = temp

    f2 = np.zeros(lab.shape)
    insert = np.ones((h))
    for i in range(w)[::-1]: # right
        temp = lab[:, i]
        temp[temp == -1] = insert[temp == -1]
        insert[temp != -1] = temp[temp != -1]
        f2[:, i] = temp
    return np.minimum(f1, f2)

def misMatchFilling(lab, cmap, r = 2):
    h, w = lab.shape[:2]
    pad_lab = pad(lab, r)
    for i in range(r, r + h):
        for j in range(r, r + w):
            if (cmap[i-r, j-r] == 1):
                lab[i-r, j-r] = np.median(pad_lab[i-r:i+r+1, j-r:j+r+1])
    return lab

def LRCC(lab1, lab2, max_disp):
    h, w = lab1.shape[:2]
    dst = np.zeros((h, w))
    mismatch = np.zeros((h, w))
    for i in range(h):
        for j in range(w):
            if lab1[i,j] == lab2[i, j-lab1[i, j]]:
                dst[i, j] = 1
            else:
                if misMatchCheck(lab2, i, j, max_disp):
                    mismatch[i, j] = 1
    return dst, mismatch

def check_(src):
    h, w = src.shape[:2]
    for i in range(h):
        for j in range(w):
            if src[i, j][0] > i:
                print("x")
            if src[i, j][1] < i:
                print("x")
            if src[i, j][2] > j:
                print("x")
            if src[i, j][3] < j:
                print("x")

def CBLSsupport(src, x, y, L = 30, thre = 50):
    boundary = []

    for i in range(x - L, x)[::-1]: # up
        try:
            # print(src[i,y])
            if i < 0 or max(abs(src[i, y] - src[x, y])) > thre:
                break
        except IndexError:
            break
    boundary.append(i + 1)

    for i in range(x + 1, x + L + 1): # down
        try:
            if i < 0 or max(abs(src[i, y] - src[x, y])) > thre:
                break
        except IndexError:
            break
    boundary.append(i - 1)

    for i in range(y - L, y)[::-1]: # left
        try:
            if i < 0 or max(abs(src[x, i] - src[x, y])) > thre:
                break
        except IndexError:
            break
    boundary.append(i + 1)

    for i in range(y + 1, y + L + 1): # right
        try:
            if i < 0 or max(abs(src[x, i] - src[x, y])) > thre:
                break
        except IndexError:
            break
    boundary.append(i - 1)
    boundary = np.asarray(boundary)
    return boundary

def CBLSregion(src):
    h, w = src.shape[:2]
    dst = np.zeros((h, w, 4), dtype = np.int16) # u, d, l, r
    for i in range(h):
        for j in range(w):
            dst[i, j, :] = CBLSsupport(src, i, j)
    
    harea = np.zeros((h, w))
    for i in range(h):
        for j in range(w):
            # print(dst[i, j][3])
            harea[i, j] = dst[i, j][3] - dst[i, j][2] + 1
    cumharea = cumFilter(harea, horizontal = False)
    for i in range(h):
        for j in range(w):
            up, down = dst[i, j][0], dst[i, j][1]
            if up == 0:
                harea[i, j] = cumharea[down, j]
            else:
                harea[i, j] = cumharea[down, j] - cumharea[up - 1, j]
    return dst, harea

def determineBorder1(src_l, src_r, i, j, d, costIsLeft):
    h, w = src_l.shape[:2]
    if costIsLeft:
        if j-d < 0 or j-d >= w:
            minimum, maximum = src_l[i, j][:2]
        else:
            minimum = max(src_l[i, j][0], src_r[i, j-d][0])
            maximum = min(src_l[i, j][1], src_r[i, j-d][1])
        return int(minimum), int(maximum)
    else:
        if j+d < 0 or j+d >= w:
            minimum, maximum = src_l[i, j][:2]
        else:
            minimum = max(src_l[i, j+d][0], src_r[i, j][0])
            maximum = min(src_l[i, j+d][1], src_r[i, j][1])
        return int(minimum), int(maximum)

def determineBorder2(src_l, src_r, i, j, d, costIsLeft):
    h, w = src_l.shape[:2]
    if costIsLeft:
        if j-d < 0 or j-d >= w:
            minimum, maximum = src_l[i, j][2:]
        else:
            minimum = max(src_l[i, j][2], src_r[i, j-d][2] + d)
            maximum = min(src_l[i, j][3], src_r[i, j-d][3] + d)
        return int(minimum), int(maximum)
    else:
        if j+d < 0 or j+d >= w:
            minimum, maximum = src_l[i, j][2:]
        else:
            minimum = max(src_l[i, j+d][2] - d, src_r[i, j][2])
            maximum = min(src_l[i, j+d][3] - d, src_r[i, j][3])
        return int(minimum), int(maximum)

def CBLSaggr(src_l, src_r, d, cost, costIsLeft, mode = True):
    '''
    src_l: region border [h, w, 4]
    src_r: region border [h, w, 4]
    d: disparity d
    cost: cost at disparity d [h, w]
    '''
    h, w = src_l.shape[:2]
    dst, area, hcost, harea  = np.zeros((h, w)), np.zeros((h, w)), np.zeros((h, w)), np.zeros((h, w))

    if mode: # horizontal first
        cumcost = cumFilter(cost, horizontal = True)
        for i in range(h):
            for j in range(w):
                left, right = determineBorder2(src_l, src_r, i, j, d, costIsLeft)
                right = w - 1 if right >= w else right
                if left == 0:
                    hcost[i, j] = cumcost[i, right]
                else:
                    hcost[i, j] = cumcost[i, right] - cumcost[i, left - 1]
                harea[i, j] = right - left + 1

        cumhcost = cumFilter(hcost, horizontal = False)
        cumharea = cumFilter(harea, horizontal = False)
        for j in range(w):
            for i in range(h):
                up, down = determineBorder1(src_l, src_r, i, j, d, costIsLeft)
                if up == 0:
                    dst[i, j] = cumhcost[down, j]
                    area[i, j] = cumharea[down, j]
                else:
                    dst[i, j] = cumhcost[down, j] - cumhcost[up - 1, j]
                    area[i, j] = cumharea[down, j] - cumharea[up - 1, j]
    else: # vertical first
        cumcost = cumFilter(cost, horizontal = False)
        for j in range(w):
            for i in range(h):
                up, down = determineBorder1(src_l, src_r, i, j, d, costIsLeft)
                # right = w - 1 if right >= w else right
                if up == 0:
                    hcost[i, j] = cumcost[down, j]
                else:
                    hcost[i, j] = cumcost[down, j] - cumcost[up - 1, j]
                harea[i, j] = down - up + 1
        cumhcost = cumFilter(hcost, horizontal = True)
        cumharea = cumFilter(harea, horizontal = True)
        for i in range(h):
            for j in range(w):
                left, right = determineBorder2(src_l, src_r, i, j, d, costIsLeft)
                right = w - 1 if right >= w else right
                if left == 0:
                    dst[i, j] = cumhcost[i, right]
                    area[i, j] = cumharea[i, right]
                else:
                    dst[i, j] = cumhcost[i, right] - cumhcost[i, left - 1]
                    area[i, j] = cumharea[i, right] - cumharea[i, left - 1]
    return dst/area

def crossBasedLocalSupport(src_l, src_r, cost, disp, costIsLeft = True, mode = True):
    '''
    src: region boundary [h, w, 4]
    '''
    # region_l = CBLSregion(boxFilter(src_l, r_box))
    # region_r = CBLSregion(boxFilter(src_r, r_box))
    dst = np.zeros(cost.shape)
    for d in range(disp):
        print(d)
        dst[:, :, d] = CBLSaggr(src_l, src_r, d, cost[:, :, d], costIsLeft, mode)
    return dst

def awLoop(p, I, eps, r):
    h, w, ch = I.shape
    N = (2*r+1)**2
    mean_I = boxFilter(I, r)/N
    mean_p = boxFilter(p, r)/N
    cov_Ip = np.zeros((h, w, ch))
    for i in range(ch):
        cov_Ip[:,:,i] = boxFilter(np.multiply(I[:,:,i], p), r)/N - np.multiply(mean_p, mean_I[:,:,i])

    k = 0
    var_I = np.zeros((h, w, 6))
    for i in range(ch):
        for j in range(i, ch):
            var_I[:,:,k] = boxFilter(np.multiply(I[:,:,i], I[:,:,j]), r)/N - np.multiply(mean_I[:,:,i],mean_I[:,:,j])
            k += 1

    a = np.zeros((h, w, ch))
    ele = np.diag([1,1,1])
    for i in range(h):
        for j in range(w):
            tt = var_I[i,j]
            sigma = np.array([[tt[0], tt[1], tt[2]], [tt[1], tt[3], tt[4]], [tt[2], tt[4], tt[5]]])
            cov = cov_Ip[i, j, :]
            a[i, j, :] = np.dot(cov, np.linalg.inv(sigma + eps * ele))

    b = mean_p - np.sum(np.multiply(a, mean_I), axis = 2)
    return (np.sum(np.multiply(boxFilter(a, r), I), axis = 2) + boxFilter(b, r))/N

def applyWeight(src, I, eps, r):
    dst = np.zeros(src.shape)
    I = I/255
    for i in range(src.shape[2]):
        # print(i)
        dst[:,:,i] = awLoop(src[:,:,i], I, eps, r)
    return dst

def bilateralWeight(src, r, s1, s2):
    h, w, ch = src.shape
    src = pad(src, r)
    eucli = eucliDist(r)
    dst = np.zeros((h, w, 2 * r + 1, 2 * r + 1))
    for i in range(r, h + r):
        for j in range(r, w + r):
            diff = ((src[i-r:i+r+1, j-r:j+r+1] - src[i, j])/255)**2
            diff = np.sum(diff, axis = 2)**0.5
            dst[i-r, j-r] = np.multiply(np.exp(-diff/s1), np.exp(-eucli/s2))
    return dst

def census(src, r):
    h, w, ch = src.shape
    src = pad(src, r)
    dst = np.zeros((h, w, (2*r+1)*(2*r+1)*3))
    for i in range(r, r+h):
        for j in range(r, r+w):
            temp = src[i-r:i+r+1, j-r:j+r+1] - src[i, j]
            temp = (temp > 0).astype(int) 
            dst[i-r, j-r, :] = temp.reshape(-1)
    return dst 

def matchingCost(Il_cen, Ir_cen, MOV, r, moving_left = True):
    h, w, ch = Il_cen.shape
    dst = np.zeros((h, w, MOV))
    for i in range(MOV):
        print(i)
        # print(i)
        if i == 0:
            dst[:,:,i] = hammingDist(Ir_cen, Il_cen)
        else:
            temp = np.zeros((h, w, (2*r+1)*(2*r+1)*3))
            if (moving_left):
                temp[:, :-i, :] = Il_cen[:, i:, :]
                dst[:,:,i] = hammingDist(Ir_cen, temp) # Il moving toward left
            else:
                temp[:, i:, :] = Ir_cen[:, :-i, :]
                dst[:,:,i] = hammingDist(Il_cen, temp) # Ir moving toward right
                # print(dst)
    return dst

def weightedMeidanFilter(lab, fil, r, disp):
    h, w = lab.shape
    dst = np.zeros((h, w))
    hist = np.zeros((h, w, disp))
    lab = pad(lab, r)

    for k in range(disp):
        temp = np.zeros(lab.shape)
        temp[lab == k] = 1
        for i in range(r, r + h):
            for j in range(r, r + w):
                W = fil[i-r, j-r]
                hist[i-r, j-r, k] = np.sum(W * temp[i-r:i+r+1, j-r:j+r+1]) / np.sum(W)

    for i in range(h):
        for j in range(w):
            temp = hist[i, j]
            sum_ = np.sum(temp)
            run_ = 0
            for k in range(disp):
                run_ += temp[k]
                if (run_ > 0.5 * sum_):
                    break
            dst[i, j] = k
    return dst

# def SLOloop(cost, Il, Ir):
#     h, w = cost.shape[:2]
#     for i in range(h):
#         for j in range(w):


# def scanLineOptimization(cost, Il, Ir, max_disp):
#     # four direction
#     # h, w = cost.shape[:2]
#     Cr = np.zeros(cost.shape)
#     for d in range(max_disp):
#         SLOloop(cost[:,:,d], Il, Ir)

#     pass


def computeDisp(Il, Ir, max_disp = 15):
    global K
    K = 1
    # K += 1
    hp = HYPER[K]
    max_disp += 1
    h, w, ch = Il.shape
    labels = np.zeros((h, w), dtype=np.uint8)
    ################# >>> Cost computation  ################
    tic = time.time()
    # TODO: Compute matching cost from Il and Ir
    Ir_cen, Il_cen = census(Ir, hp['CENSUS_R']), census(Il, hp['CENSUS_R']) ## (h, w, (2*r+1)**2*3)
    costv1 = matchingCost(Il_cen, Ir_cen, max_disp, hp['CENSUS_R'], moving_left = False)
    costv1 = np.minimum(hp['TRUNC'] * np.ones((h, w, max_disp)), costv1)
    # labels = np.argmin(costv1, axis = 2)
    # cv2.imwrite('tsukuba0.png', np.uint8(labels * 16))
    toc = time.time()
    print('* Elapsed time (cost computation): %f sec.' % (toc - tic))

    ################ >>> Cost aggregation  ################
    tic = time.time()
    # TODO: Refine cost by aggregate nearby costs
    region_l, area_l = CBLSregion(boxFilter(Il, 1))
    region_r, area_r = CBLSregion(boxFilter(Ir, 1))
    # labels = np.argmin(costv1, axis = 2)
    # cv2.imwrite('tsukuba_11.png', np.uint8(labels * 16))
    costv1 = crossBasedLocalSupport(region_l, region_r, costv1, max_disp, costIsLeft = True, mode = True)
    costv1 = crossBasedLocalSupport(region_l, region_r, costv1, max_disp, costIsLeft = True, mode = False)
    # costv1 = crossBasedLocalSupport(region_l, region_r, costv1, max_disp, costIsLeft = True, mode = True) 
    # costv1 = crossBasedLocalSupport(region_l, region_r, costv1, max_disp, costIsLeft = True, mode = False) 
    # labels = np.argmin(costv1, axis = 2)
    # cv2.imwrite('tsukuba_12.png', np.uint8(labels * 16))
    # costv1 = SGM(costv1)
    # costv1 = applyWeight(costv1, Il, hp['EPS'], hp['AGG_R'])
    toc = time.time()
    print('* Elapsed time (cost aggregation): %f sec.' % (toc - tic))

    ################ >>> Disparity optimization  ################
    tic = time.time()
    # TODO: Find optimal disparity based on estimated cost. Usually winner-take-all.
    labels = np.argmin(costv1, axis = 2)
    # labels = 
    # cv2.imwrite('tsukuba1.png', np.uint8(labels * 16))
    toc = time.time()
    print('* Elapsed time (disparity optimization): %f sec.' % (toc - tic))

    ################ >>> Disparity refinement  ################
    tic = time.time()
    # TODO: Do whatever to enhance the disparity map
    # ex: Left-right consistency check + hole filling + weighted median filtering
    costv2 = matchingCost(Il_cen, Ir_cen, max_disp, hp['CENSUS_R'], moving_left = True)
    costv2 = np.minimum(hp['TRUNC'] * np.ones((h, w, max_disp)), costv2)
    costv2 = crossBasedLocalSupport(region_l, region_r, costv2, max_disp, costIsLeft = False, mode = True)
    costv2 = crossBasedLocalSupport(region_l, region_r, costv2, max_disp, costIsLeft = False, mode = False)
    # costv2 = crossBasedLocalSupport(region_l, region_r, costv2, max_disp, costIsLeft = False, mode = True)
    # costv2 = crossBasedLocalSupport(region_l, region_r, costv2, max_disp, costIsLeft = False, mode = False)
    # costv2 = applyWeight(costv2, Ir, hp['EPS'], hp['AGG_R'])
    labels_ = np.argmin(costv2, axis = 2)
    checkMap, mismatch = LRCC(labels, labels_, max_disp) # first left, second right
    cv2.imwrite('tsukuba_1.png', np.uint8(labels * 16))
    labels, checkMap = regionFilling(labels, checkMap, region_l, area_l)
    labels, checkMap = regionFilling(labels, checkMap, region_l, area_l)
    # labels, checkMap = regionFilling(labels, checkMap, region_l, area_l)
    # labels, checkMap = regionFilling(labels, checkMap, region_l, area_l)
    cv2.imwrite('tsukuba_2.png', np.uint8(labels * 16))

    labels = misMatchFilling(labels, mismatch)
    labels = holeFilling(labels, checkMap + mismatch)
    # cv2.imwrite('tsukuba2.png', np.uint8(labels * 16))
    Il_wei = bilateralWeight(Il, hp['BFWMF_R'], hp['S1'], hp['S2'])
    labels = weightedMeidanFilter(labels, Il_wei, hp['BFWMF_R'], max_disp)
    toc = time.time()
    print('* Elapsed time (disparity refinement): %f sec.' % (toc - tic))

    return labels

def disparity(img_left, img_right, max_disp):
    labels = computeDisp(img_left, img_right, max_disp)
    return labels


# def main():
    # print('Tsukuba')
    # img_left = cv2.imread('./testdata/tsukuba/im3.png')
    # img_right = cv2.imread('./testdata/tsukuba/im4.png')
    # max_disp = 15
    # scale_factor = 16
    # labels = computeDisp(img_left, img_right, max_disp)
    # cv2.imwrite('tsukuba.png', np.uint8(labels * scale_factor))

    # print('Venus')
    # img_left = cv2.imread('./testdata/venus/im2.png')
    # img_right = cv2.imread('./testdata/venus/im6.png')
    # max_disp = 20
    # scale_factor = 8
    # labels = computeDisp(img_left, img_right, max_disp)
    # cv2.imwrite('venus.png', np.uint8(labels * scale_factor))

    # print('Teddy')
    # img_left = cv2.imread('./testdata/teddy/im2.png')
    # img_right = cv2.imread('./testdata/teddy/im6.png')
    # max_disp = 60
    # scale_factor = 4
    # labels = computeDisp(img_left, img_right, max_disp)
    # cv2.imwrite('teddy.png', np.uint8(labels * scale_factor))

    # print('Cones')
    # img_left = cv2.imread('./testdata/cones/im2.png')
    # img_right = cv2.imread('./testdata/cones/im6.png')
    # max_disp = 60
    # scale_factor = 4
    # labels = computeDisp(img_left, img_right, max_disp)
    # cv2.imwrite('cones.png', np.uint8(labels * scale_factor))

    # os.system('python eval_stereo.py')

# if __name__ == '__main__':
#     main()
